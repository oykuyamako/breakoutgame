
//I removed my comment lines of codes, and added the removebrick() function for removing bricks both for pellets and ball (which you asked about it in the class) 
//I added the reload page code when space button is pressed after dying. I gave ball and pellet a gradient background similiar to playarea background and paddle background
//I did not make major changes other than this.
//Also, I havent been able to locate the problem about playarea's and paddle's display problem with other computers, it works correctly on my computer. I added 2 screenshots
//from chrome and opera browsers. I am sorry for late editing, I misread the due time.




var game = {};
var playArea = {};
var game2 ={};
var ball = {};
var lp = {};
var temp= 0;
var bricks=[];
var balllocarr=[];
var hitpoint;
var started=false;
var pellets={};
var fired=false;
var audiodie = new Audio('fail.mp3');
var audiocoin = new Audio('coin.mp3');
var lifes={};

var pelletSpeed=0;
var paddleMargin = 700;
var paddleSpeed = 300 / 1000;
var ballSpeed = 0;//250/1000;
var lastTick = 0;
var controls = {
	player1UP : "a",
	player1DOWN : "d",
	start : " ",
	fire : "z",
	
}

var keysPressed = {};

function init(){
	
	initGOs();

	lifes.dom = document.getElementById("lifearea");
	lifes.count = 3;
	lifes.dom.innerHTML = ("Lifes = " + lifes.count);

	document.addEventListener("keydown", function (keyEvent){
		keysPressed[keyEvent.key] = true;
	});
	document.addEventListener("keyup", function (keyEvent){
		keysPressed[keyEvent.key] = false;
	});

	requestAnimationFrame(loop);
}


function loop(ts){

	var delta = ts - lastTick;

	handleInput(delta);
	updateGame(delta);

	lastTick = ts;
	requestAnimationFrame(loop);
}

function handleInput(dt){

	if(keysPressed[controls.player1UP]) {
		lp.x -= dt * paddleSpeed; 
		if(lp.x < 10){
			lp.x=10;
		}
		if(!started){
			ball.x=lp.x+(lp.width/2-10);;
		}
	}
	if(keysPressed[controls.player1DOWN]) {
		lp.x += dt * paddleSpeed;
		if(lp.x > playArea.width-lp.width-20){
			lp.x=playArea.width-lp.width-20;
		} 
		if(!started){
			ball.x=lp.x+(lp.width/2-10);;
		}
	}
	if(keysPressed[controls.start]){
		started=true;
		if(lifes.count==0){lifes.count=3;audiodie.pause();location.reload();}
		
		ballSpeed = 250/1000;
	}
	if(keysPressed[controls.fire]){

		if(fired==false){

			fired=true;
 			pellets.dom =document.createElement("pellets");
 			pellets.dom.setAttribute("class","pellets");
 			playArea.dom.appendChild(pellets.dom);
 			pellets.width=10;
 			pellets.height=10;
 			pellets.x=lp.x;
 			pellets.y=lp.y-20;
 			pellets.isitball=false;
 	

		}
		
	}

	if(lp.y<0){
		lp.y=0;
	}
	if(lp.y>playArea.height-lp.height){
		lp.y = playArea.height-lp.height;
	}


 


	updateDOMFromGO(lp);
	
}
function removebrick(a,bricks){

	for(var i=0;i<30;i++){

		if(bricks[i]!=null && aabbcollision(a,bricks[i])){
			if(fired==true && a.isitball==false){
				playArea.dom.removeChild(a.dom);
				fired=false;
			}
			if(a.isitball==true){
				a.direction.y *= -1;
			}

			if(bricks[i].hitpoint>=1){
				playArea.dom.removeChild(bricks[i].dom);
				audiocoin.play();
				bricks.splice(i,1,null);
			}
			else{
				bricks[i].hitpoint+=1;
				bricks[i].dom.style.backgroundColor="pink";
			}
		}
	}


}

function updateGame(delta){
	ball.x += delta * ballSpeed * ball.direction.x;
	ball.y += delta * ballSpeed * ball.direction.y;

	if(fired==true){
 		

		pelletSpeed=100/1000;
		pellets.y += delta * pelletSpeed *-1;

		if(pellets.y<=1){
			playArea.dom.removeChild(pellets.dom);
			fired=false;
		}
		
		updateDOMFromGO(pellets);

	}
	removebrick(pellets,bricks);
		
	if(ball.x < 0){
		ball.x = 0;
		ball.direction.x *= -1;;
	
	}
	if(ball.x > playArea.width - ball.width){
		ball.x = playArea.width - ball.width;
		ball.direction.x *= -1;
		
	}
	if(ball.y < 0){
		ball.y = 0;
		ball.direction.y *= -1;;
	}
	if(ball.y > playArea.height - ball.height){
		ball.y = playArea.height - ball.height;
		lifes.count-=1;
		started=false;
		ball.x=lp.x+(lp.width/2-10);
		ball.y=lp.y-20;
		
			ballSpeed=0;
		
		if(lifes.count==0){
			audiodie.play();
			
		}
		
	}
	if(aabbcollision(ball,lp)){
		
		ball.direction.y *= -1;
		
	}
	removebrick(ball,bricks);
	
	
	lifes.dom.innerHTML = ("Lifes = " + lifes.count);
	if(lifes.count==0){
		lifes.dom.innerHTML = ("GAME OVER");

	}
	
	updateDOMFromGO(ball)
};



function initGOs(){


 	playArea.dom = document.getElementById("playArea");
 	playArea.width = playArea.dom.offsetWidth;
 	playArea.height = playArea.dom.offsetHeight;
 	playArea.x = (game.width - playArea.width)/2;
 	playArea.y = (game.height - playArea.height)/2;
 
 	updateDOMFromGO(playArea);


 	lp.dom = document.getElementById("leftPaddle");
 	lp.width = lp.dom.offsetHeight;
 	lp.height = lp.dom.offsetWidth;
 	lp.x = paddleMargin;
 	lp.y = ((playArea.width - lp.width)/2+100);
 
 	updateDOMFromGO(lp);

 	ball.dom = document.getElementById("ball");
 	ball.width = ball.dom.offsetWidth;
 	ball.height = ball.dom.offsetHeight;
 	ball.x = lp.x+(lp.width/2-10);
 	ball.y = lp.y-20;
 	ball.direction = {
		x : 1,
		y : 1
	}
	ball.isitball=true;
 
 	updateDOMFromGO(ball);


	var xpos=(playArea.width - 70)/2-350;
 	var ypos=(playArea.width - 70)/2-550;

 	for(var i=0;i<30;i++){

 	bricks[i]=[{}];
 	bricks[i].hitpoint=0;
 	
	
 	bricks[i].dom =document.createElement("brick");
 	bricks[i].dom.setAttribute("class","brick");
 	playArea.dom.appendChild(bricks[i].dom);

 	
 	bricks[i].width=120;
 	bricks[i].height=30;
 	bricks[i].x=xpos;
 	bricks[i].y=ypos+temp*50;

 	updateDOMFromGO(bricks[i]);

 	temp++;

 		if(temp==5){
 			temp=0;
 			xpos+=150;

 		}

 	}





}





function updateDOMFromGO(go){

	go.dom.style.width = go.width + "px";
	go.dom.style.height = go.height + "px";
	go.dom.style.top = go.y + "px";
	go.dom.style.left = go.x + "px";

}


function aabbcollision(go1,go2){
	if(go1.x < go2.x + go2.width && go1.x + go1.width > go2.x && 
		go1.y < go2.y + go2.height && go1.y + go1.height > go2.y){return true;}

	else{return false;}

}